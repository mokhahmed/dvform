# dvform
Dataform utility library that allow fast bootstrapping for data-vault model on bigquery 
